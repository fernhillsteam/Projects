<link rel="icon" type="image/png" href="http://webdamn.com/wp-content/themes/v2/webdamn.png">
</head>
<body class="">
<nav class="navbar navbar-expand-sm bg-light">
  <ul class="navbar-nav">
    <li class="nav-item">
     <a href="http://www.webdamn.com" class="navbar-brand">WEBDAMN.COM</a>
    </li>
    <li class="nav-item">
      <a  class="nav-link" href="http://www.webdamn.com">Home</a>
    </li>    
  </ul>
</nav>
<div class="container" style="min-height:500px;">
	