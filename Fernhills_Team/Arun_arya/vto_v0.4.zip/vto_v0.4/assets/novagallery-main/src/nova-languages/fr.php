<?php defined("NOVA") or die(); ?>
{
  "login": "S’identifier",
  "logout": "Quitter la session",
  "password": "Mot de passe",
  "back": "Retour",
  "404-/-page-not-found": "404 / Page non trouvée",
  "sorry-this-page-does-not-seem-to-exist": "Désolé, il semble que la page n'existe pas.",
  "back-to-home": "Retour à la page d'accueil"
}