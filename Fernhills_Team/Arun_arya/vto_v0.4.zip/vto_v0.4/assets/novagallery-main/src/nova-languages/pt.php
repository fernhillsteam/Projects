<?php defined("NOVA") or die(); ?>
{
  "login": "Login",
  "logout": "Logout",
  "password": "Senha",
  "back": "Voltar",
  "404-/-page-not-found": "404 / Página não encontrada",
  "sorry-this-page-does-not-seem-to-exist": "Desculpe, esta página parece não existir.",
  "back-to-home": "Voltar à página inicial"
}