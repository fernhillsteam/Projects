<?php
/**
 * novaGallery
 * @author novafacile OÜ
 * @copyright Copyright (c) 2021 by novafacile OÜ
 * @license AGPL-3.0
 * @version 1.0
 * @link https://novagallery.org
 **/

require_once('nova-base/init.php');

?>
