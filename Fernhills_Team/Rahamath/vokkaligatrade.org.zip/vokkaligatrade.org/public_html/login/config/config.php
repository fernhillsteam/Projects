<!-- <?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'u152216168_vto');
define('DB_USER', 'u152216168_vto');
define('DB_PASS', 'Vto@1234567890');


?> -->

<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'u949021360_vto');
define('DB_USER', 'u949021360_vto');
define('DB_PASS', 'Vto@1234');


?>